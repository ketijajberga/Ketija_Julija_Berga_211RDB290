# VPN Risinājumu Mērījumu Dati

Šajā repozitorijā ir apkopoti VPN risinājumu (IPsec, Netmaker, OpenVPN, WireGuard, ZeroTier) testēšanas mērījumu dati.

## Mapju struktūra

| Mape | Saturs |
|------|--------|
| `1_normali_statistika` | Normālu tīkla apstākļu statistikas kopsavilkums (LAN-LAN, Attālinātā piekļuve, Mākoņintegrācija) |
| `2_normali_raw` | Normālu tīkla apstākļu pilnie mērījumi pa protokoliem |
| `3_slikti_statistika` | Pasliktinātu tīkla apstākļu statistikas kopsavilkums (LAN-LAN, Attālinātā piekļuve) |
| `4_slikti_raw` | Pasliktinātu tīkla apstākļu pilnie mērījumi pa protokoliem |
| `5_kvalitativa_vertesana` | Kvalitatīvā novērtēšana (konfigurācija, pārvaldāmība, drošība, izmaksas) |
| `6_savienojuma_laiks` | Savienojuma atjaunošanas laika mērījumi |
